/* RETRO REVIVALS - COLLECTION APP v3
   Works with the tracker pages and saves collection progress in the browser.
*/
(function () {
  "use strict";

  var STORAGE_KEY = "retro_revivals_collection_v3";

  function getOwned() {
    try {
      var saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  }

  function setOwned(data) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.warn("Retro Revivals: local storage is unavailable.");
    }
  }

  function updateStats() {
    var boxes = Array.prototype.slice.call(document.querySelectorAll(".check"));
    var owned = boxes.filter(function (box) { return box.checked; }).length;
    var total = Number(window.PAGE_TOTAL) || boxes.length;
    var percent = total ? Math.round((owned / total) * 100) : 0;

    var count = document.querySelector("[data-owned-count]");
    var pct = document.querySelector("[data-percent]");
    var bars = document.querySelectorAll(".progress");

    if (count) count.textContent = owned + " / " + total;
    if (pct) pct.textContent = percent + "%";

    Array.prototype.forEach.call(bars, function (bar) {
      bar.style.width = percent + "%";
    });
  }

  function applyOwnedState() {
    var data = getOwned();

    Array.prototype.forEach.call(document.querySelectorAll(".check"), function (box) {
      var id = box.getAttribute("data-id");
      box.checked = !!data[id];

      var card = box.closest ? box.closest(".card") : null;
      if (card) card.classList.toggle("owned", box.checked);
    });

    updateStats();
  }

  function saveCheckbox(box) {
    var data = getOwned();
    var id = box.getAttribute("data-id");

    if (!id) return;

    data[id] = box.checked;
    setOwned(data);

    var card = box.closest ? box.closest(".card") : null;
    if (card) card.classList.toggle("owned", box.checked);

    updateStats();
  }

  function filterCards() {
    var search = document.getElementById("search");
    var ownedSelect = document.getElementById("owned");

    var query = search ? search.value.toLowerCase().trim() : "";
    var ownedFilter = ownedSelect ? ownedSelect.value : "All";

    Array.prototype.forEach.call(document.querySelectorAll(".card"), function (card) {
      var text = (card.textContent || "").toLowerCase();
      var box = card.querySelector(".check");
      var matchesSearch = !query || text.indexOf(query) !== -1;

      var matchesOwned =
        ownedFilter === "All" ||
        (ownedFilter === "Owned" && box && box.checked) ||
        (ownedFilter === "Missing" && box && !box.checked);

      card.style.display = matchesSearch && matchesOwned ? "" : "none";
    });
  }

  function exportCollection() {
    var data = getOwned();
    var rows = [["ID", "Owned"]];

    Object.keys(data).sort().forEach(function (id) {
      rows.push([id, data[id] ? "Yes" : "No"]);
    });

    var csv = rows.map(function (row) {
      return row.map(function (value) {
        var text = String(value);
        return '"' + text.replace(/"/g, '""') + '"';
      }).join(",");
    }).join("\r\n");

    var blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var link = document.createElement("a");

    link.href = url;
    link.download = "retro-revivals-collection.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 1000);
  }

  function resetCollection() {
    var confirmed = window.confirm("Reset your Retro Revivals collection?");
    if (!confirmed) return;

    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) {}

    window.location.reload();
  }

  function updateMyCollectionPage() {
    var counter = document.getElementById("mycount");
    var bar = document.getElementById("mybar");

    if (!counter && !bar) return;

    var data = getOwned();
    var owned = Object.keys(data).filter(function (id) {
      return data[id] === true;
    }).length;

    if (counter) counter.textContent = owned;

    if (bar) {
      var total = 199;
      var percent = Math.min(100, Math.round((owned / total) * 100));
      bar.style.width = percent + "%";
    }
  }

  function bind() {
    Array.prototype.forEach.call(document.querySelectorAll(".check"), function (box) {
      box.addEventListener("change", function () {
        saveCheckbox(box);
        filterCards();
      });
    });

    var search = document.getElementById("search");
    if (search) {
      search.addEventListener("input", filterCards);
      search.addEventListener("keyup", filterCards);
    }

    var owned = document.getElementById("owned");
    if (owned) {
      owned.addEventListener("change", filterCards);
    }

    applyOwnedState();
    filterCards();
    updateMyCollectionPage();
  }

  /* Make functions available to the HTML onclick buttons. */
  window.exportCollection = exportCollection;
  window.resetCollection = resetCollection;
  window.filterCards = filterCards;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bind);
  } else {
    bind();
  }
})();
